CREATE VIEW v_cc AS
  SELECT
    `tester`.`student`.`stuID`   AS `stuID`,
    `tester`.`student`.`classID` AS `classID`,
    `tester`.`student`.`stuName` AS `stuName`
  FROM `tester`.`student`;

