CREATE VIEW view_kdjsl AS
  SELECT
    `tester`.`score`.`courseID` AS `courseID`,
    `tester`.`score`.`stuID`    AS `stuID`,
    `tester`.`score`.`course`   AS `course`,
    `tester`.`score`.`score`    AS `score`,
    `tester`.`score`.`id`       AS `id`
  FROM `tester`.`score`;

