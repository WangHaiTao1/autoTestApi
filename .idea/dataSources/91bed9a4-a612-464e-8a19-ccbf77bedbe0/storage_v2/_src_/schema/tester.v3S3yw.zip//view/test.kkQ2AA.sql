CREATE VIEW test AS
  SELECT
    `a`.`stuName`   AS `stuname`,
    `b`.`score`     AS `score`,
    `c`.`classNAME` AS `classname`
  FROM ((`tester`.`student` `a`
    JOIN `tester`.`score` `b` ON ((`a`.`stuID` = `b`.`stuID`))) JOIN `tester`.`class` `c`
      ON ((`a`.`classID` = `c`.`classID`)))
  WHERE ((`a`.`stuName` = '李丽') AND (`c`.`classNAME` = '一班'));

