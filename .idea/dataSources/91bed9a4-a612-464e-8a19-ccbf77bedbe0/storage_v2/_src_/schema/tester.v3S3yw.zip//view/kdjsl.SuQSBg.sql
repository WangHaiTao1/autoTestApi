CREATE VIEW kdjsl AS
  SELECT `tester`.`score1`.`score` AS `score`
  FROM `tester`.`score1`
  UNION ALL SELECT `tester`.`score`.`score` AS `score`
            FROM `tester`.`score`;

