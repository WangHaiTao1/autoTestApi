CREATE PROCEDURE sp_customer()
  BEGIN
-- 需要执行的SQL语句
	DECLARE v_sql_1 VARCHAR(500);
	DECLARE v_sql_2 VARCHAR(500);
	DECLARE v_sql_3 VARCHAR(500);
	-- 定义变量
	DECLARE companyId INT; 
	DECLARE maxId1 INT; 
	DECLARE maxId2 INT; 
	-- 定义游标遍历时，作为判断是否遍历完全部记录的标记
	DECLARE num INT DEFAULT 0;
	-- 定义游标，并将sql结果集赋值到游标中
	DECLARE company_list CURSOR FOR SELECT company_id,max_id FROM customer_job WHERE id>1;
	-- 声明当游标遍历完全部记录后将标志变量置成某个值
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET num=1;
    
    -- DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET num = 1;  
	-- 打开游标
	OPEN company_list; 
		-- 将游标中的值赋值给变量，要注意sql结果列的顺序
		FETCH company_list INTO companyId,maxId1; 
		-- while循环
		WHILE num <> 1 DO
			-- 动态拼接sql并赋值v_sql_1
			SET v_sql_1 = CONCAT('select max(id) into @param1 from customer',companyId);
			-- 需要用@转换下,直接v_sql_1执行不了
			SET @sql_1 = v_sql_1;
			-- 预处理需要执行的动态SQL，其中stmt是一个变量
			PREPARE stmt1 FROM @sql_1;  
			-- 执行SQL语句
			EXECUTE stmt1;   
			-- 释放掉预处理段   
			DEALLOCATE PREPARE stmt1;     
			-- @param1赋值给maxId2
			SET maxId2 = @param1;
			
			-- 动态拼接sql并赋值v_sql_2
			SET v_sql_2 = CONCAT('insert into customer(name,sex,age,card_id,phone,email,addr,company,group,tag,stage,phone_state,loan_type,loan_amount,company_id,data_from) ',
								' select name,sex,age,card_id,phone,email,addr,company,group,tag,stage,phone_state,loan_type,loan_amount,company_id,data_from from customer',companyId,
								' where id>',maxId1,' and id<=',maxId2);
			SET @sql_2 = v_sql_2;
			-- 预处理需要执行的动态SQL，其中stmt是一个变量
			PREPARE stmt2 FROM @sql_2;  
			-- 执行SQL语句
			EXECUTE stmt2;   
			-- 释放掉预处理段   
			DEALLOCATE PREPARE stmt2;     
			
			-- 动态拼接sql并赋值v_sql_3
			SET v_sql_3 = CONCAT('update customer_job set update_num=update_num,max_id=',maxId2,' where company_id=',companyId);
			SET @sql_3 = v_sql_3;
			-- 预处理需要执行的动态SQL，其中stmt是一个变量
			PREPARE stmt3 FROM @sql_3;  
			-- 执行SQL语句
			EXECUTE stmt3;   
			-- 释放掉预处理段   
			DEALLOCATE PREPARE stmt3;     
			
			-- 将游标中的值赋值给变量，要注意sql结果列的顺序
			FETCH company_list INTO companyId; 
		END WHILE;
	-- 关闭游标
	CLOSE company_list;
END;

